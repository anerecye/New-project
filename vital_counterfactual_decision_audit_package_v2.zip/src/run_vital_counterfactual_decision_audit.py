from __future__ import annotations

import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BASE_DIR / "data" / "processed"
SUPPLEMENT_DIR = BASE_DIR / "supplementary_tables"
FIGURE_DIR = BASE_DIR / "figures"

VARIANT_DESIGN_OUT = DATA_DIR / "vital_counterfactual_decision_audit_variant_design.csv"
SUMMARY_OUT = DATA_DIR / "vital_counterfactual_decision_audit_summary.csv"
BY_MECHANISM_OUT = DATA_DIR / "vital_counterfactual_decision_audit_by_mechanism.csv"
BY_AF_BIN_OUT = DATA_DIR / "vital_counterfactual_decision_audit_by_af_bin.csv"
PATIENT_SUMMARY_OUT = DATA_DIR / "vital_counterfactual_decision_audit_patient_summary.csv"
SENSITIVITY_OUT = DATA_DIR / "vital_counterfactual_decision_audit_sensitivity_summary.csv"
CONFLICTING_VARIANTS_OUT = DATA_DIR / "vital_counterfactual_decision_audit_clinvar_conflicting_variants.csv"
DOMINANT_GOLD_OUT = DATA_DIR / "vital_counterfactual_decision_audit_dominant_gold_standard.csv"
SUPPLEMENT_OUT = SUPPLEMENT_DIR / "Supplementary_Table_S57_counterfactual_decision_audit.tsv"
FIGURE_OUT = FIGURE_DIR / "vital_counterfactual_decision_audit.png"

ARRHYTHMIA_SCORES = DATA_DIR / "arrhythmia_vital_scores.csv"
CONTROL_SCORES = DATA_DIR / "control_vital_scores.csv"

SEED = 20260428
N_VARIANTS = 1_000
N_PATIENTS = 10_000

ANCESTRY_PROPORTIONS = {
    "nfe": 0.42,
    "afr": 0.18,
    "amr": 0.16,
    "eas": 0.12,
    "sas": 0.09,
    "asj": 0.03,
}

MCAF_BY_MECHANISM = {
    "GoF_DN": 1e-5,
    "HI": 3e-5,
    "AR": 5e-3,
    "low_penetrance": 1e-3,
}

AF_BINS = [1e-6, 3e-6, 1e-5, 3e-5, 1e-4, 3e-4, 1e-3, 3e-3, 1e-2]
AF_BIN_LABELS = [
    "1e-6_to_3e-6",
    "3e-6_to_1e-5",
    "1e-5_to_3e-5",
    "3e-5_to_1e-4",
    "1e-4_to_3e-4",
    "3e-4_to_1e-3",
    "1e-3_to_3e-3",
    "3e-3_to_1e-2",
]


def save_table(df: pd.DataFrame, path: Path, sep: str = ",") -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, sep=sep, index=False, lineterminator="\n")
    print(f"Saved {path} ({len(df)} rows)")


def mechanism_probabilities(popmax_af: np.ndarray) -> np.ndarray:
    af_position = (np.log10(popmax_af) + 6) / 4
    gof = 0.42 * np.power(1 - af_position, 1.8) + 0.015
    hi = 0.30 * np.power(1 - af_position, 0.7) + 0.08
    ar = 0.10 + 0.70 * np.power(af_position, 1.35)
    low_penetrance = 0.06 + 0.30 * af_position
    raw = np.vstack([gof, hi, ar, low_penetrance]).T
    return raw / raw.sum(axis=1, keepdims=True)


def assign_mechanisms(popmax_af: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    labels = np.array(["GoF_DN", "HI", "AR", "low_penetrance"])
    probs = mechanism_probabilities(popmax_af)
    draws = rng.random(len(popmax_af))
    cumulative = probs.cumsum(axis=1)
    return labels[(draws[:, None] > cumulative).sum(axis=1)]


def assign_penetrance(mechanisms: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    penetrance = np.empty(len(mechanisms))
    for mechanism in np.unique(mechanisms):
        mask = mechanisms == mechanism
        n = int(mask.sum())
        if mechanism == "GoF_DN":
            values = 0.55 + 0.40 * rng.beta(8, 2, n)
        elif mechanism == "HI":
            values = 0.15 + 0.65 * rng.beta(4, 4, n)
        elif mechanism == "AR":
            values = 0.60 + 0.35 * rng.beta(7, 2, n)
        else:
            values = 0.005 + 0.07 * rng.beta(2, 18, n)
        penetrance[mask] = values
    return penetrance


def assign_genes(mechanisms: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    genes = np.empty(len(mechanisms), dtype=object)
    ar_indices = np.where(mechanisms == "AR")[0]
    non_ar_indices = np.where(mechanisms != "AR")[0]
    ar_gene_count = 90
    non_ar_gene_count = 180
    ar_genes = np.array([f"SIM_AR_{i:03d}" for i in range(1, ar_gene_count + 1)])
    non_ar_genes = np.array([f"SIM_DOM_{i:03d}" for i in range(1, non_ar_gene_count + 1)])
    genes[ar_indices] = rng.choice(ar_genes, size=len(ar_indices), replace=True)
    genes[non_ar_indices] = rng.choice(non_ar_genes, size=len(non_ar_indices), replace=True)
    return genes


def annotate_vital_route(design: pd.DataFrame) -> pd.DataFrame:
    design = design.copy()
    design["dominant_model_conflict_by_frequency"] = (
        design["mechanism"].isin(["GoF_DN", "HI"])
        & design["popmax_af"].gt(design["mcaf"] * 10)
    ) | (
        design["mechanism"].eq("low_penetrance")
        & design["popmax_af"].gt(design["mcaf"])
    )
    design["vital_variant_route"] = np.select(
        [
            design["mechanism"].eq("AR"),
            design["mechanism"].eq("low_penetrance"),
            design["popmax_af"].gt(design["mcaf"] * 10),
            design["popmax_af"].gt(design["mcaf"]),
        ],
        [
            "mechanism_aware_AR_check",
            "low_penetrance_check",
            "MODEL_CONFLICT",
            "CHECK_DEFER",
        ],
        default="VITAL_OK",
    )
    return design


def build_variant_design(rng: np.random.Generator) -> tuple[pd.DataFrame, pd.DataFrame]:
    ancestries = np.array(list(ANCESTRY_PROPORTIONS))
    ancestry_weights = np.array(list(ANCESTRY_PROPORTIONS.values()))
    popmax_af = np.power(10.0, rng.uniform(-6, -2, N_VARIANTS))
    mechanisms = assign_mechanisms(popmax_af, rng)
    penetrance = assign_penetrance(mechanisms, rng)
    genes = assign_genes(mechanisms, rng)
    popmax_ancestry = rng.choice(ancestries, size=N_VARIANTS, replace=True, p=ancestry_weights)

    ancestry_af = pd.DataFrame({"variant_id": [f"CFDA-{i:04d}" for i in range(1, N_VARIANTS + 1)]})
    for ancestry in ancestries:
        fraction = np.power(10.0, rng.uniform(-2.0, -0.15, N_VARIANTS))
        ancestry_af[ancestry] = popmax_af * fraction
        ancestry_af.loc[popmax_ancestry == ancestry, ancestry] = popmax_af[popmax_ancestry == ancestry]
    weighted_global_af = np.zeros(N_VARIANTS)
    for ancestry, weight in ANCESTRY_PROPORTIONS.items():
        weighted_global_af += ancestry_af[ancestry].to_numpy() * weight

    design = pd.DataFrame(
        {
            "variant_id": ancestry_af["variant_id"],
            "gene": genes,
            "mechanism": mechanisms,
            "popmax_af": popmax_af,
            "global_af": weighted_global_af,
            "popmax_ancestry": popmax_ancestry,
            "penetrance": penetrance,
            "mcaf": [MCAF_BY_MECHANISM[m] for m in mechanisms],
        }
    )
    design["af_bin"] = pd.cut(design["popmax_af"], AF_BINS, labels=AF_BIN_LABELS, include_lowest=True)
    return annotate_vital_route(design), ancestry_af


def simulate_genotypes(
    design: pd.DataFrame,
    ancestry_af: pd.DataFrame,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray]:
    ancestries = np.array(list(ANCESTRY_PROPORTIONS))
    ancestry_weights = np.array(list(ANCESTRY_PROPORTIONS.values()))
    patients = rng.choice(ancestries, size=N_PATIENTS, replace=True, p=ancestry_weights)
    patient_ancestry_index = pd.Series(patients).map({a: i for i, a in enumerate(ancestries)}).to_numpy()
    af_matrix = ancestry_af.loc[:, ancestries].to_numpy(dtype=float)

    genotypes = np.zeros((N_VARIANTS, N_PATIENTS), dtype=np.uint8)
    for variant_index in range(N_VARIANTS):
        p = af_matrix[variant_index, patient_ancestry_index]
        hom_probability = np.square(p)
        carrier_probability = 2 * p * (1 - p) + hom_probability
        draws = rng.random(N_PATIENTS)
        genotypes[variant_index] = np.select(
            [draws < hom_probability, draws < carrier_probability],
            [2, 1],
            default=0,
        ).astype(np.uint8)
    patients_df = pd.DataFrame({"patient_id": [f"SIM-P{i:05d}" for i in range(1, N_PATIENTS + 1)], "ancestry": patients})
    return genotypes, patients_df


def ar_actionable_matrix(design: pd.DataFrame, genotypes: np.ndarray) -> np.ndarray:
    actionable = np.zeros_like(genotypes, dtype=bool)
    ar_variant_indices = np.where(design["mechanism"].to_numpy() == "AR")[0]
    for gene in design.loc[ar_variant_indices, "gene"].unique():
        indices = np.where((design["mechanism"].to_numpy() == "AR") & (design["gene"].to_numpy() == gene))[0]
        if len(indices) == 0:
            continue
        gene_genotypes = genotypes[indices]
        homozygous = gene_genotypes == 2
        heterozygous = gene_genotypes == 1
        compound = heterozygous.sum(axis=0) >= 2
        actionable[indices] = homozygous | (heterozygous & compound)
    return actionable


def outcome_counts(
    design: pd.DataFrame,
    genotypes: np.ndarray,
    rng: np.random.Generator,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    mechanisms = design["mechanism"].to_numpy()
    popmax_af = design["popmax_af"].to_numpy()
    mcaf = design["mcaf"].to_numpy()
    penetrance = design["penetrance"].to_numpy()

    carrier = genotypes > 0
    heterozygous_only = genotypes == 1
    ar_actionable = ar_actionable_matrix(design, genotypes)
    dominant_actionable_genotype = carrier & np.isin(mechanisms, ["GoF_DN", "HI", "low_penetrance"])[:, None]
    disease_eligible = dominant_actionable_genotype | ar_actionable
    disease_draws = rng.random(genotypes.shape)
    true_disease_action = disease_eligible & (disease_draws < penetrance[:, None])

    baseline_action = carrier
    baseline_false = baseline_action & ~true_disease_action
    baseline_correct = baseline_action & true_disease_action

    vital_correct = np.zeros_like(carrier, dtype=bool)
    vital_false = np.zeros_like(carrier, dtype=bool)
    vital_deferred = np.zeros_like(carrier, dtype=bool)
    vital_conflict = np.zeros_like(carrier, dtype=bool)

    for i, mechanism in enumerate(mechanisms):
        if mechanism == "AR":
            vital_correct[i] = baseline_action[i] & true_disease_action[i] & ar_actionable[i]
            vital_conflict[i] = baseline_action[i] & heterozygous_only[i] & ~ar_actionable[i]
            vital_deferred[i] = baseline_action[i] & ~vital_correct[i] & ~vital_conflict[i]
        elif mechanism == "low_penetrance":
            vital_deferred[i] = baseline_action[i]
        elif popmax_af[i] > 10 * mcaf[i]:
            vital_conflict[i] = baseline_action[i]
        elif popmax_af[i] > mcaf[i]:
            vital_deferred[i] = baseline_action[i]
        else:
            vital_correct[i] = baseline_action[i] & true_disease_action[i]
            vital_false[i] = baseline_action[i] & ~true_disease_action[i]

    variant_rows = []
    for i, row in design.iterrows():
        variant_rows.append(
            {
                "variant_id": row["variant_id"],
                "gene": row["gene"],
                "mechanism": row["mechanism"],
                "af_bin": row["af_bin"],
                "popmax_af": row["popmax_af"],
                "mcaf": row["mcaf"],
                "penetrance": row["penetrance"],
                "carriers": int(baseline_action[i].sum()),
                "homozygotes": int((genotypes[i] == 2).sum()),
                "true_disease_actions": int(true_disease_action[i].sum()),
                "baseline_false_clinical_actions": int(baseline_false[i].sum()),
                "baseline_correct_actions": int(baseline_correct[i].sum()),
                "vital_false_clinical_actions": int(vital_false[i].sum()),
                "vital_correct_actions": int(vital_correct[i].sum()),
                "vital_deferred": int(vital_deferred[i].sum()),
                "vital_model_conflict": int(vital_conflict[i].sum()),
            }
        )
    variant_outcomes = pd.DataFrame(variant_rows)

    summary = pd.DataFrame(
        [
            {
                "strategy": "label_driven_baseline",
                "analysis_layer": design.attrs.get("analysis_layer", "primary_simulation"),
                "patient_variant_routes": int(baseline_action.sum()),
                "false_clinical_action": int(baseline_false.sum()),
                "correct_action": int(baseline_correct.sum()),
                "deferred": 0,
                "model_conflict": 0,
                "false_action_percent_of_routes": 100 * baseline_false.sum() / baseline_action.sum(),
            },
            {
                "strategy": "VITAL_mechanism_popmax_MCAF_routing",
                "analysis_layer": design.attrs.get("analysis_layer", "primary_simulation"),
                "patient_variant_routes": int(baseline_action.sum()),
                "false_clinical_action": int(vital_false.sum()),
                "correct_action": int(vital_correct.sum()),
                "deferred": int(vital_deferred.sum()),
                "model_conflict": int(vital_conflict.sum()),
                "false_action_percent_of_routes": 100 * vital_false.sum() / baseline_action.sum(),
            },
        ]
    )
    baseline_false_count = int(baseline_false.sum())
    vital_false_count = int(vital_false.sum())
    summary["false_action_reduction_vs_baseline_percent"] = [
        0.0,
        100 * (baseline_false_count - vital_false_count) / baseline_false_count if baseline_false_count else math.nan,
    ]

    group_rows = []
    for mechanism, sub in variant_outcomes.groupby("mechanism", sort=False):
        group_rows.append(summarize_outcome_group("mechanism", mechanism, sub))
    by_mechanism = pd.DataFrame(group_rows)

    af_rows = []
    for af_bin, sub in variant_outcomes.groupby("af_bin", observed=True, sort=False):
        af_rows.append(summarize_outcome_group("af_bin", str(af_bin), sub))
    by_af_bin = pd.DataFrame(af_rows)

    patient_summary = pd.DataFrame(
        {
            "patient_id": [f"SIM-P{i:05d}" for i in range(1, N_PATIENTS + 1)],
            "baseline_any_false_clinical_action": baseline_false.any(axis=0),
            "baseline_any_correct_action": baseline_correct.any(axis=0),
            "vital_any_false_clinical_action": vital_false.any(axis=0),
            "vital_any_correct_action": vital_correct.any(axis=0),
            "vital_any_deferred": vital_deferred.any(axis=0),
            "vital_any_model_conflict": vital_conflict.any(axis=0),
            "baseline_false_action_count": baseline_false.sum(axis=0),
            "vital_false_action_count": vital_false.sum(axis=0),
            "vital_deferred_count": vital_deferred.sum(axis=0),
            "vital_model_conflict_count": vital_conflict.sum(axis=0),
        }
    )

    return summary, by_mechanism, by_af_bin, variant_outcomes, patient_summary


def permute_mechanism_design(design: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    permuted = design.copy()
    permuted["mechanism"] = rng.permutation(permuted["mechanism"].to_numpy())
    permuted["penetrance"] = assign_penetrance(permuted["mechanism"].to_numpy(), rng)
    permuted["gene"] = assign_genes(permuted["mechanism"].to_numpy(), rng)
    permuted["mcaf"] = [MCAF_BY_MECHANISM[m] for m in permuted["mechanism"]]
    permuted.attrs["analysis_layer"] = "permuted_mechanism_sensitivity"
    return annotate_vital_route(permuted)


def summarize_outcome_group(group_type: str, group: str, sub: pd.DataFrame) -> dict[str, object]:
    baseline_false = int(sub["baseline_false_clinical_actions"].sum())
    vital_false = int(sub["vital_false_clinical_actions"].sum())
    return {
        "group_type": group_type,
        "group": group,
        "variant_count": len(sub),
        "carrier_routes": int(sub["carriers"].sum()),
        "baseline_false_clinical_actions": baseline_false,
        "baseline_correct_actions": int(sub["baseline_correct_actions"].sum()),
        "vital_false_clinical_actions": vital_false,
        "vital_correct_actions": int(sub["vital_correct_actions"].sum()),
        "vital_deferred": int(sub["vital_deferred"].sum()),
        "vital_model_conflict": int(sub["vital_model_conflict"].sum()),
        "false_action_reduction_percent": 100 * (baseline_false - vital_false) / baseline_false
        if baseline_false
        else math.nan,
    }


def load_clinvar_conflicting_variants() -> pd.DataFrame:
    scores = pd.read_csv(ARRHYTHMIA_SCORES, low_memory=False)
    conflict_mask = scores["review_status"].fillna("").astype(str).str.lower().str.contains(
        "multiple submitters, no conflicts", regex=False
    )
    ranked = scores.loc[conflict_mask].sort_values(
        ["standard_acmg_frequency_flag", "frequency_signal_ac_ge_20", "vital_score", "popmax_af"],
        ascending=[False, False, False, False],
    )
    selected = ranked.drop_duplicates("variant_key", keep="first").head(186).copy()
    selected["validation_set"] = "clinvar_conflicting_variants_current_arrhythmia"
    selected["set_size_target"] = 186
    selected["vital_route"] = np.select(
        [
            selected["vital_red_flag"].fillna(False).astype(bool),
            selected["frequency_signal_ac_ge_20"].fillna(False).astype(bool),
            selected["standard_acmg_frequency_flag"].fillna(False).astype(bool),
        ],
        ["MODEL_CONFLICT", "CHECK_DEFER", "CHECK_DEFER"],
        default="VITAL_OK",
    )
    selected["sensitivity_interpretation"] = (
        "Current arrhythmia ClinVar multiple-submitters/no-conflicts records used as a reviewer-consensus "
        "conflicting layer, not expert truth; VITAL should route frequency-tension cases rather than silently "
        "accept label-driven dominant action."
    )
    return selected


def load_dominant_gold_standard() -> pd.DataFrame:
    scores = pd.read_csv(CONTROL_SCORES, low_memory=False)
    expert = scores["review_status"].fillna("").astype(str).str.lower().str.contains(
        "reviewed by expert panel|practice guideline", regex=True
    )
    dominant_genes = scores["gene"].isin(["BRCA1", "BRCA2", "MLH1", "APC"])
    non_red = ~scores["vital_red_flag"].fillna(False).astype(bool)
    ranked = scores.loc[expert & dominant_genes & non_red].sort_values(
        ["frequency_evidence_status", "vital_score", "gene", "variant_key"],
        ascending=[True, True, True, True],
    )
    selected = ranked.drop_duplicates("variant_key", keep="first").head(42).copy()
    selected["validation_set"] = "gold_standard_dominant_expert_positive"
    selected["set_size_target"] = 42
    selected["assumed_mechanism"] = "dominant_actionable"
    selected["sensitivity_result"] = np.where(
        selected["vital_red_flag"].fillna(False).astype(bool),
        "false_interruption",
        "preserved_or_deferred",
    )
    selected["sensitivity_interpretation"] = (
        "Expert-panel dominant P/LP positive control for sensitivity; VITAL should avoid hard red interruption."
    )
    return selected


def build_sensitivity_summary(
    primary_summary: pd.DataFrame,
    permuted_summary: pd.DataFrame,
    conflicting: pd.DataFrame,
    dominant_gold: pd.DataFrame,
) -> pd.DataFrame:
    rows = []
    for layer_name, table in [("primary_simulation", primary_summary), ("permuted_mechanism_sensitivity", permuted_summary)]:
        vital = table.loc[table["strategy"].eq("VITAL_mechanism_popmax_MCAF_routing")].iloc[0]
        rows.append(
            {
                "sensitivity_layer": layer_name,
                "n_variants": N_VARIANTS,
                "patient_variant_routes": int(vital["patient_variant_routes"]),
                "false_clinical_action": int(vital["false_clinical_action"]),
                "correct_action": int(vital["correct_action"]),
                "deferred": int(vital["deferred"]),
                "model_conflict": int(vital["model_conflict"]),
                "false_action_percent_of_routes": float(vital["false_action_percent_of_routes"]),
                "interpretation": "Monte Carlo decision audit under the stated mechanism-AF architecture."
                if layer_name == "primary_simulation"
                else "Mechanism labels permuted across AF values to test whether the result depends circularly on frequency-structured mechanism assignment.",
            }
        )
    rows.append(
        {
            "sensitivity_layer": "clinvar_conflicting_variants",
            "n_variants": len(conflicting),
            "patient_variant_routes": math.nan,
            "false_clinical_action": math.nan,
            "correct_action": math.nan,
            "deferred": int(conflicting["vital_route"].eq("CHECK_DEFER").sum()),
            "model_conflict": int(conflicting["vital_route"].eq("MODEL_CONFLICT").sum()),
            "false_action_percent_of_routes": math.nan,
            "interpretation": "Current ClinVar multiple-submitters/no-conflicts arrhythmia layer (n=186) validates routing on reviewer-consensus conflicting records, not expert truth.",
        }
    )
    rows.append(
        {
            "sensitivity_layer": "gold_standard_dominant_expert_positive",
            "n_variants": len(dominant_gold),
            "patient_variant_routes": math.nan,
            "false_clinical_action": int(dominant_gold["sensitivity_result"].eq("false_interruption").sum()),
            "correct_action": int(dominant_gold["sensitivity_result"].ne("false_interruption").sum()),
            "deferred": int(dominant_gold["vital_band"].fillna("").astype(str).str.contains("gray|yellow", case=False, regex=True).sum()),
            "model_conflict": int(dominant_gold["sensitivity_result"].eq("false_interruption").sum()),
            "false_action_percent_of_routes": 100 * dominant_gold["sensitivity_result"].eq("false_interruption").sum() / len(dominant_gold),
            "interpretation": "Gold-standard dominant expert-positive set (n=42) tests sensitivity/preservation; hard red interruption should be zero or near-zero.",
        }
    )
    return pd.DataFrame(rows)


def plot_summary(summary: pd.DataFrame) -> None:
    plot_df = summary.set_index("strategy").loc[
        ["label_driven_baseline", "VITAL_mechanism_popmax_MCAF_routing"],
        ["false_clinical_action", "correct_action", "deferred", "model_conflict"],
    ]
    fig, ax = plt.subplots(figsize=(8, 4.8))
    bottom = np.zeros(len(plot_df))
    colors = {
        "false_clinical_action": "#b23a48",
        "correct_action": "#2a9d8f",
        "deferred": "#e9c46a",
        "model_conflict": "#6d597a",
    }
    for column in plot_df.columns:
        ax.bar(plot_df.index, plot_df[column], bottom=bottom, label=column.replace("_", " "), color=colors[column])
        bottom += plot_df[column].to_numpy()
    ax.set_ylabel("Patient-variant label-driven routes")
    ax.set_title("Counterfactual decision audit", weight="bold")
    ax.legend(frameon=False, fontsize=8)
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIGURE_OUT, dpi=220)
    plt.close(fig)
    print(f"Saved {FIGURE_OUT}")


def main() -> None:
    rng = np.random.default_rng(SEED)
    design, ancestry_af = build_variant_design(rng)
    design.attrs["analysis_layer"] = "primary_simulation"
    genotypes, patients = simulate_genotypes(design, ancestry_af, rng)
    summary, by_mechanism, by_af_bin, variant_outcomes, patient_summary = outcome_counts(design, genotypes, rng)
    patient_summary = patients.merge(patient_summary, on="patient_id", how="left")
    variant_design = design.merge(variant_outcomes, on=["variant_id", "gene", "mechanism", "af_bin", "popmax_af", "mcaf", "penetrance"])

    permuted_rng = np.random.default_rng(SEED + 1)
    permuted_design = permute_mechanism_design(design, permuted_rng)
    permuted_summary, _, _, _, _ = outcome_counts(permuted_design, genotypes, permuted_rng)
    conflicting = load_clinvar_conflicting_variants()
    dominant_gold = load_dominant_gold_standard()
    sensitivity = build_sensitivity_summary(summary, permuted_summary, conflicting, dominant_gold)

    save_table(variant_design, VARIANT_DESIGN_OUT)
    save_table(summary, SUMMARY_OUT)
    save_table(by_mechanism, BY_MECHANISM_OUT)
    save_table(by_af_bin, BY_AF_BIN_OUT)
    save_table(patient_summary, PATIENT_SUMMARY_OUT)
    save_table(sensitivity, SENSITIVITY_OUT)
    save_table(conflicting, CONFLICTING_VARIANTS_OUT)
    save_table(dominant_gold, DOMINANT_GOLD_OUT)
    supplement = pd.concat(
        [
            summary.assign(table_section="strategy_summary"),
            by_mechanism.assign(table_section="mechanism_summary"),
            by_af_bin.assign(table_section="af_bin_summary"),
            sensitivity.assign(table_section="sensitivity_summary"),
        ],
        ignore_index=True,
        sort=False,
    )
    save_table(supplement.fillna("NA"), SUPPLEMENT_OUT, sep="\t")
    plot_summary(summary)
    print(summary.to_string(index=False))
    print("\nSensitivity summary")
    print(sensitivity.to_string(index=False))


if __name__ == "__main__":
    main()
